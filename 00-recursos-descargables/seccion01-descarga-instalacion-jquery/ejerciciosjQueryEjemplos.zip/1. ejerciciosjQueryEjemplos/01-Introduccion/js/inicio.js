// JavaScript Document
$(document).ready(inicio);
function inicio(){
	termina();
}