$(document).ready(inicio);

function inicio(){
	$("#afrodita").click(onDesaparece)
}
function onDesaparece(){
	$("#afrodita").css("background-image","url(../imagenes/afrodita.jpg)");
}